Mi página contiene una barra de navegación con la que podremos dirigirnos a diferentes zonas de la página. 
En "inicio" nos llevará directamente a la página principal, que está mi foto y dice quien soy.
En "mis proyectos" se encuentra la zona dónde he puesto los cursos informáticos que tengo y que estoy aprendiendo, si ponemos encima el cursor veremos que la imagen se amplia y si clickamos en cada una de ellas aparecerá el texto correspondiente al curso realizado. Si volvemos a hacer click, aparecerá de nuevo toda la información junta.
En "mi cv" nos lleva directamente a mi cv.
Y en "Formulario" nos lleva a la página donde podemos introducir unos datos y valida si ha introducido un correo electrónico.
Por último tenemos un footer personalizado que nos redigirá a las distintas redes sociales.